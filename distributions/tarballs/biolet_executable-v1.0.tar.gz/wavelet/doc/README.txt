In order to use wavelet you need to be able to read the libs from wavelet/libs
you will likely want to do something like

export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:wavelet/libs/
